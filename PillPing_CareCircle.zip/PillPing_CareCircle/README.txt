PILLPING – CARECIRCLE
=====================

A browser-based hackathon prototype for elderly-friendly medication reminders and caregiver oversight.

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome or Edge recommended).
3. Add medicines from the Schedule tab.
4. Use My medicines to confirm doses.
5. Open Caregiver to see completed, pending and missed doses.
6. Open Weekly history to see the 7-day scorecard.

FEATURES
- Large, high-contrast interface and large tap targets.
- Add medicine name, dosage, morning/afternoon/night, time, food instructions and stock.
- One-tap dose confirmation, snooze and already-took option.
- Caregiver dashboard with daily adherence and alerts.
- Missed dose escalation after 30 minutes (while the app is running).
- Weekly adherence scorecard.
- Browser speech read-aloud.
- SOS call shortcut using caregiver phone number.
- Data stored in browser LocalStorage.

IMPORTANT LIMITATIONS
- This is a front-end demonstration, not a production medical application.
- Data stays in the current browser/device; there is no cloud sync or remote caregiver login.
- Missed-dose checks and reminders require the page to remain open. Browser notification permission may be requested, but reliable background alarms are not guaranteed.
- Caregiver alerts are simulated in the dashboard, not sent by SMS, email or push service.
- This app does not prescribe or change medication. Follow the prescription and clinician's instructions.
