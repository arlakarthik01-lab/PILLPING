const $=id=>document.getElementById(id);
const key='pillping-data-v1';
const todayKey=()=>new Date().toISOString().slice(0,10);
const defaults=[
 {id:1,name:'Amlodipine',dose:'5 mg',period:'Morning',time:'08:00',food:'As prescribed',stock:20},
 {id:2,name:'Metformin',dose:'500 mg',period:'Afternoon',time:'13:00',food:'With food',stock:24},
 {id:3,name:'Aspirin',dose:'75 mg',period:'Night',time:'20:00',food:'After food',stock:18}
];
let data=JSON.parse(localStorage.getItem(key)||'null')||{meds:defaults,logs:{},alerts:[],carePhone:''};
function save(){localStorage.setItem(key,JSON.stringify(data))}
function logKey(id,date=todayKey()){return date+'_'+id}
function status(m){return data.logs[logKey(m.id)]?.status||'pending'}
function toast(msg){$('toast').textContent=msg;$('toast').style.display='block';setTimeout(()=>$('toast').style.display='none',3000)}
function showView(view){document.querySelectorAll('.view').forEach(v=>v.classList.toggle('hidden',v.id!==view));document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.view===view));if(view==='caregiver')renderCare();if(view==='history')renderHistory()}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
$('today').textContent=new Date().toLocaleDateString(undefined,{weekday:'long',month:'short',day:'numeric'});
function renderMeds(){
 const list=$('medicineList');list.innerHTML='';
 if(!data.meds.length){list.innerHTML='<div class="panel">No medicines added yet. Add one from the Schedule tab.</div>';return}
 data.meds.slice().sort((a,b)=>a.time.localeCompare(b.time)).forEach(m=>{
  const s=status(m), card=document.createElement('article');card.className='card';
  card.innerHTML=`<div class="cardtop"><span class="pill">${m.period}</span><span class="muted">${m.time}</span></div><div class="medname">${esc(m.name)}</div><p class="medmeta">${esc(m.dose)} · ${esc(m.food)}</p><p class="medmeta">Remaining: ${m.stock} doses</p><div class="status ${s==='taken'?'done':'pending'}">${s==='taken'?'✓ Taken':s==='missed'?'⚠ Missed':'● Pending'}</div>${s==='pending'?'<button class="primary" style="margin-top:12px;width:100%" data-take="'+m.id+'">I took this medicine</button>':''}`;
  list.appendChild(card);
 });
 list.querySelectorAll('[data-take]').forEach(b=>b.addEventListener('click',()=>confirmDose(+b.dataset.take)));
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function confirmDose(id){const m=data.meds.find(x=>x.id===id);if(!m)return;data.logs[logKey(id)]={status:'taken',at:new Date().toISOString()};m.stock=Math.max(0,(+m.stock||0)-1);data.alerts.unshift({type:'done',message:m.name+' confirmed taken at '+new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}),at:Date.now()});save();renderMeds();renderCare();$('reminder').classList.add('hidden');toast('Good job! Your medicine is marked as taken.')}
function currentReminder(){const now=new Date(),mins=now.getHours()*60+now.getMinutes();return data.meds.find(m=>{let [h,mi]=m.time.split(':').map(Number);return status(m)==='pending'&&mins>=h*60+mi&&mins<h*60+mi+30})}
function checkReminders(){const now=new Date(),mins=now.getHours()*60+now.getMinutes();data.meds.forEach(m=>{let [h,mi]=m.time.split(':').map(Number),due=h*60+mi;if(status(m)==='pending'&&mins>=due+30&&!data.alerts.some(a=>a.type==='missed'&&a.medId===m.id&&a.date===todayKey())){data.logs[logKey(m.id)]={status:'missed'};data.alerts.unshift({type:'missed',medId:m.id,date:todayKey(),message:'Missed dose: '+m.name+' — caregiver attention needed',at:Date.now()});save();toast('Care alert: '+m.name+' has not been confirmed.')}});let m=currentReminder();if(m){$('reminderName').textContent=m.name+' · '+m.dose;$('reminderInfo').textContent=m.period+' · '+m.time+' · '+m.food;$('reminder').classList.remove('hidden');window.activeMed=m.id;}renderMeds();if(!$('caregiver').classList.contains('hidden'))renderCare()}
$('takenBtn').onclick=()=>window.activeMed&&confirmDose(window.activeMed);
$('alreadyBtn').onclick=()=>window.activeMed&&confirmDose(window.activeMed);
$('snoozeBtn').onclick=()=>{$('reminder').classList.add('hidden');toast('Reminder snoozed for 15 minutes (while this page remains open).');setTimeout(()=>{let m=data.meds.find(x=>x.id===window.activeMed);if(m&&status(m)==='pending'){$('reminderName').textContent=m.name+' · '+m.dose;$('reminderInfo').textContent=m.period+' · '+m.time;$('reminder').classList.remove('hidden')}},900000)};
$('medicineForm').addEventListener('submit',e=>{e.preventDefault();data.meds.push({id:Date.now(),name:$('medName').value.trim(),dose:$('medDose').value.trim(),period:$('medTime').value,time:$('medClock').value,food:$('medFood').value,stock:+$('medStock').value||0});data.carePhone=$('carePhone').value.trim()||data.carePhone;save();e.target.reset();$('medStock').value=30;$('medClock').value='08:00';renderMeds();toast('Medicine saved');showView('home')});
$('addShortcut').onclick=()=>showView('schedule');
function renderCare(){let total=data.meds.length,taken=data.meds.filter(m=>status(m)==='taken').length,missed=data.meds.filter(m=>status(m)==='missed').length,pending=total-taken-missed,percent=total?Math.round(taken/total*100):0;$('takenCount').textContent=taken;$('pendingCount').textContent=pending;$('missedCount').textContent=missed;$('progressBar').style.width=percent+'%';$('progressText').textContent=percent+'% of today’s scheduled medicines confirmed.';let alerts=data.alerts.slice(0,12);$('alerts').innerHTML=alerts.length?alerts.map(a=>`<div class="alert ${a.type==='missed'?'red':''}">${a.type==='missed'?'⚠':'✓'} ${esc(a.message)}</div>`).join(''):'<p class="muted">No caregiver alerts yet.</p>'}
function renderHistory(){let dates=[];for(let i=6;i>=0;i--){let d=new Date();d.setDate(d.getDate()-i);dates.push(d)}let completed=0,total=0;$('weekGrid').innerHTML=dates.map(d=>{let k=d.toISOString().slice(0,10),logs=data.meds.map(m=>data.logs[logKey(m.id,k)]?.status).filter(Boolean),t=logs.filter(s=>s==='taken').length,m=logs.filter(s=>s==='missed').length;completed+=t;total+=t+m;let cls=logs.length?(m?'bad':t?'good':''):'',label=d.toLocaleDateString(undefined,{weekday:'short'});return `<div class="day ${cls}"><small>${label}</small><b>${t}/${data.meds.length}</b></div>`}).join('');$('weeklyScore').textContent=total?Math.round(completed/total*100)+'%':'—'}
$('voiceBtn').onclick=()=>{if(!('speechSynthesis'in window)){toast('Read aloud is not supported by this browser.');return}let text=data.meds.map(m=>`${m.name}, ${m.dose}, ${m.period}, ${m.food}`).join('. ');speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(text||'No medicines scheduled'))};
$('sosLink').onclick=e=>{if(!data.carePhone){e.preventDefault();toast('Add a caregiver phone number in Schedule first.');return}e.currentTarget.href='tel:'+data.carePhone};
renderMeds();renderCare();renderHistory();checkReminders();setInterval(checkReminders,30000);
if('Notification'in window&&Notification.permission==='default'){setTimeout(()=>Notification.requestPermission(),1500)}
